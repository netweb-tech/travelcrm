<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GuideExpense extends Model
{
    protected $table="guide_expense";
}
