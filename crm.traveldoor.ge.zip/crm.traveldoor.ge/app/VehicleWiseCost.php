<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehicleWiseCost extends Model
{
     protected $table="vehicle_wise_cost";
}
