<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubAmenities extends Model
{
     protected $table="sub_amenities";
}
