<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnquiryComments extends Model
{
    protected $table="enquiry_comments";
}
