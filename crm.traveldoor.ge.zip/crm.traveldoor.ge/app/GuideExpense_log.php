<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GuideExpense_log extends Model
{
     protected $table="guide_expense_log";
}
