<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SightSeeing extends Model
{
    protected $table="sightseeing";
}
