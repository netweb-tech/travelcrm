<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Guides extends Model
{
    protected $table="guides";
}
