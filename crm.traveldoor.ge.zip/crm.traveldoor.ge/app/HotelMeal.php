<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HotelMeal extends Model
{
    protected $table="hotel_meals";
}
