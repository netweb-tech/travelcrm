<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehicleWiseCost_log extends Model
{
     protected $table="vehicle_wise_cost_log";
}
