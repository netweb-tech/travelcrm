<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SightSeeing_log extends Model
{
    protected $table="sightseeing_log";
}
