<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agents_log extends Model
{
    protected $table="agents_log";
}
