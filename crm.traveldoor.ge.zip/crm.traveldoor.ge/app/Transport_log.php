<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transport_log extends Model
{
    protected $table="transport_log";
}