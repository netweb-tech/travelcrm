<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookingCustomer extends Model
{
    protected $table="booking_customer";
}
