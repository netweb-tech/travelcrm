<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Activities_log extends Model
{
   protected $table="activities_log";
}
