<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Guides_log extends Model
{
    protected $table="guides_log";
}
