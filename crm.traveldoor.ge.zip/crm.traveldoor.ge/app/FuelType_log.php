<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FuelType_log extends Model
{
    protected $table="fuel_type_log";
}
