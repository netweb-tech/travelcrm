<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hotels_log extends Model
{
   protected $table="hotels_log";
}
